import pytest
from datetime import date
from crawler.parser import parse_price, parse_flight_results


def test_parse_price_brl():
    assert parse_price("R$ 1.234,56") == 1234.56

def test_parse_price_integer():
    assert parse_price("R$ 890,00") == 890.0

def test_parse_price_invalid():
    assert parse_price("Indisponível") is None

def test_parse_flight_results_empty():
    results = parse_flight_results(
        "<html><body>Sem resultados</body></html>",
        "GRU", "MIA",
        "https://www.cvc.com.br/passagens-aereas/gru-mia/",
        date(2025, 7, 10), date(2025, 7, 17),
    )
    assert results == []
