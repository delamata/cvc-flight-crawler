import asyncio
import sys
import os
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from crawler.cvc_spider import run_full_crawl
from api.database import AsyncSessionLocal, FlightPrice
from loguru import logger

INTERVAL = int(os.getenv("CRAWLER_INTERVAL_MIN", 30))


async def crawl_and_save():
    logger.info("Iniciando ciclo de coleta...")
    results = await run_full_crawl()
    async with AsyncSessionLocal() as db:
        for r in results:
            db.add(FlightPrice(**r))
        await db.commit()
    logger.success(f"{len(results)} registros salvos.")


def start_scheduler():
    scheduler = AsyncIOScheduler()
    scheduler.add_job(crawl_and_save, "interval", minutes=INTERVAL, id="cvc_crawl")
    scheduler.start()
    logger.info(f"Scheduler ativo — coleta a cada {INTERVAL} min.")
    return scheduler


if __name__ == "__main__":
    async def main():
        once = "--once" in sys.argv
        if once:
            logger.info("Modo --once: executando coleta única.")
            await crawl_and_save()
        else:
            start_scheduler()
            await crawl_and_save()
            await asyncio.Event().wait()

    asyncio.run(main())
