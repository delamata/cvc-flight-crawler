from pydantic import BaseModel
from datetime import datetime


class FlightPriceOut(BaseModel):
    id: int
    origin: str
    destination: str
    departure_date: str
    return_date: str
    nights: int
    airline: str
    base_price: float | None
    final_price: float
    var_pct: float | None
    url: str
    collected_at: datetime

    class Config:
        from_attributes = True
