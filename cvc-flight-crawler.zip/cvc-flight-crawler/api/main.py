from fastapi import FastAPI, Depends, Query
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from api.database import AsyncSessionLocal, FlightPrice, init_db
from api.models import FlightPriceOut
from contextlib import asynccontextmanager
from loguru import logger


@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    logger.info("API iniciada — banco pronto.")
    yield


app = FastAPI(title="CVC Flight Price API", version="1.0.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # restrinja em produção
    allow_methods=["GET"],
    allow_headers=["*"],
)


async def get_db():
    async with AsyncSessionLocal() as session:
        yield session


@app.get("/feed", response_model=list[FlightPriceOut])
async def get_feed(
    origin: str | None = Query(None, description="IATA de origem"),
    destination: str | None = Query(None, description="IATA de destino"),
    flight_type: str | None = Query(None, alias="type", description="DOM ou INT"),
    limit: int = Query(200, le=1000),
    db: AsyncSession = Depends(get_db),
):
    q = select(FlightPrice).order_by(desc(FlightPrice.collected_at)).limit(limit)
    if origin:
        q = q.where(FlightPrice.origin == origin.upper())
    if destination:
        q = q.where(FlightPrice.destination == destination.upper())
    result = await db.execute(q)
    return result.scalars().all()


@app.get("/feed/latest", response_model=list[FlightPriceOut])
async def get_latest(db: AsyncSession = Depends(get_db)):
    q = select(FlightPrice).order_by(desc(FlightPrice.collected_at)).limit(50)
    result = await db.execute(q)
    return result.scalars().all()


@app.get("/health")
async def health():
    return {"status": "ok", "service": "cvc-flight-crawler"}
