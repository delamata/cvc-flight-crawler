from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import DeclarativeBase, sessionmaker, mapped_column, Mapped
from sqlalchemy import String, Float, DateTime, Integer, func
from datetime import datetime
import os

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite+aiosqlite:///./cvc_feed.db")

engine = create_async_engine(DATABASE_URL, echo=False)
AsyncSessionLocal = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)


class Base(DeclarativeBase):
    pass


class FlightPrice(Base):
    __tablename__ = "flight_prices"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    origin: Mapped[str] = mapped_column(String(4))
    destination: Mapped[str] = mapped_column(String(4))
    departure_date: Mapped[str] = mapped_column(String(10))
    return_date: Mapped[str] = mapped_column(String(10))
    nights: Mapped[int] = mapped_column(Integer)
    airline: Mapped[str] = mapped_column(String(60))
    base_price: Mapped[float] = mapped_column(Float, nullable=True)
    final_price: Mapped[float] = mapped_column(Float)
    var_pct: Mapped[float] = mapped_column(Float, nullable=True)
    url: Mapped[str] = mapped_column(String(512))
    collected_at: Mapped[datetime] = mapped_column(DateTime, default=func.now())


async def init_db():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
