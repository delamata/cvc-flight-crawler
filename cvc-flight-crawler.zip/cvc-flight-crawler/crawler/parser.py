from bs4 import BeautifulSoup
from datetime import date
from loguru import logger
import re


def parse_price(text: str) -> float | None:
    """Extrai float de strings como 'R$ 1.234,56'"""
    clean = re.sub(r"[^\d,]", "", text).replace(",", ".")
    try:
        return float(clean)
    except ValueError:
        return None


def parse_flight_results(
    html: str,
    origin: str,
    dest: str,
    url: str,
    dep_date: date,
    ret_date: date,
) -> list[dict]:
    soup = BeautifulSoup(html, "html.parser")
    results = []

    # ⚠️  ATENÇÃO: Seletores precisam ser validados contra o HTML real do site.
    #     Execute o crawler uma vez com HEADLESS=false e inspecione o DOM.
    cards = (
        soup.select("[data-testid='flight-result']")
        or soup.select(".resultado-voo")
        or soup.select(".flight-card")
        or soup.select("[class*='FlightCard']")
        or soup.select("[class*='result-item']")
    )

    for card in cards:
        try:
            price_el = (
                card.select_one(".preco")
                or card.select_one(".price")
                or card.select_one("[class*='price']")
                or card.select_one("[class*='preco']")
                or card.select_one("[class*='valor']")
            )
            airline_el = (
                card.select_one(".companhia")
                or card.select_one(".airline")
                or card.select_one("[class*='airline']")
                or card.select_one("[class*='companhia']")
            )

            if not price_el:
                continue

            price = parse_price(price_el.get_text())
            airline = airline_el.get_text(strip=True) if airline_el else "N/A"

            if price:
                results.append({
                    "origin": origin,
                    "destination": dest,
                    "departure_date": dep_date.isoformat(),
                    "return_date": ret_date.isoformat(),
                    "nights": (ret_date - dep_date).days,
                    "airline": airline,
                    "final_price": price,
                    "url": url,
                })
        except Exception as e:
            logger.debug(f"Erro ao parsear card: {e}")
            continue

    return results
