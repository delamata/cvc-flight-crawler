from playwright.async_api import async_playwright, Browser, BrowserContext
from loguru import logger
import os

_browser: Browser | None = None
_context: BrowserContext | None = None


async def get_browser() -> BrowserContext:
    global _browser, _context
    if _context is None:
        pw = await async_playwright().start()
        _browser = await pw.chromium.launch(
            headless=os.getenv("HEADLESS", "true").lower() == "true",
            args=["--no-sandbox", "--disable-dev-shm-usage"],
        )
        _context = await _browser.new_context(
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/124.0.0.0 Safari/537.36"
            ),
            viewport={"width": 1366, "height": 768},
            locale="pt-BR",
        )
        logger.info("Browser Playwright iniciado.")
    return _context


async def close_browser():
    global _browser, _context
    if _browser:
        await _browser.close()
        _browser = None
        _context = None
        logger.info("Browser encerrado.")
