# Rotas monitoradas — Saídas do Sudeste (domésticas + internacionais)

SUDESTE_ORIGINS = [
    "GRU", "CGH", "VCP",   # São Paulo
    "GIG", "SDU",           # Rio de Janeiro
    "CNF", "PLU",           # Belo Horizonte
    "VIX",                  # Vitória
]

DOMESTIC_DESTINATIONS = [
    "SSA", "FOR", "REC", "MAO", "BEL", "CWB", "POA",
    "FLN", "NAT", "MCZ", "BSB", "CGR", "GYN", "SLZ",
    "THE", "JPA", "AJU", "CGB", "PVH", "GYN", "LDB",
    "MGF", "JOI", "XAP", "CXJ", "IOS", "PMW",
]

INTERNATIONAL_DESTINATIONS = [
    "EZE", "SCL", "LIM", "BOG", "MVD", "ASU", "CCS",
    "MIA", "JFK", "ORD", "LAX", "DFW", "ATL",
    "MEX", "CUN", "YYZ",
    "CDG", "LHR", "MAD", "LIS", "FCO", "FRA",
    "AMS", "BCN", "MXP", "ZRH", "VIE", "CPH",
    "NRT", "ICN", "SYD", "SIN", "DXB", "DOH", "BKK",
]

def get_all_routes() -> list[dict]:
    routes = []
    for origin in SUDESTE_ORIGINS:
        for dest in DOMESTIC_DESTINATIONS:
            routes.append({"origin": origin, "destination": dest, "type": "DOM"})
        for dest in INTERNATIONAL_DESTINATIONS:
            routes.append({"origin": origin, "destination": dest, "type": "INT"})
    return routes
