import asyncio
import os
from datetime import date, timedelta
from loguru import logger
from tenacity import retry, stop_after_attempt, wait_exponential
from crawler.browser import get_browser
from crawler.parser import parse_flight_results
from crawler.routes import get_all_routes

BASE_URL = os.getenv("CVC_BASE_URL", "https://www.cvc.com.br")


def build_url(origin: str, dest: str, dep_date: date, ret_date: date) -> str:
    dep = dep_date.strftime("%Y%m%d")
    ret = ret_date.strftime("%Y%m%d")
    return f"{BASE_URL}/passagens-aereas/{origin.lower()}-{dest.lower()}/?dataIda={dep}&dataVolta={ret}"


@retry(stop=stop_after_attempt(3), wait=wait_exponential(min=2, max=10))
async def scrape_route(origin: str, dest: str, dep_date: date, ret_date: date) -> list[dict]:
    ctx = await get_browser()
    page = await ctx.new_page()
    url = build_url(origin, dest, dep_date, ret_date)
    results = []
    try:
        logger.info(f"Acessando: {url}")
        await page.goto(url, timeout=30_000, wait_until="networkidle")
        await page.wait_for_selector(
            "[data-testid='flight-result'], .resultado-voo, .flight-card, [class*='FlightCard']",
            timeout=15_000,
        )
        html = await page.content()
        results = parse_flight_results(html, origin, dest, url, dep_date, ret_date)
        logger.success(f"{origin}→{dest}: {len(results)} tarifa(s)")
    except Exception as e:
        logger.warning(f"Erro em {origin}→{dest}: {e}")
    finally:
        await page.close()
    return results


async def run_full_crawl(days_ahead: int = 30, nights: int = 7) -> list[dict]:
    routes = get_all_routes()
    dep_date = date.today() + timedelta(days=days_ahead)
    ret_date = dep_date + timedelta(days=nights)

    all_results = []
    semaphore = asyncio.Semaphore(3)

    async def bounded(r):
        async with semaphore:
            await asyncio.sleep(1.5)
            return await scrape_route(r["origin"], r["destination"], dep_date, ret_date)

    chunks = await asyncio.gather(*[bounded(r) for r in routes], return_exceptions=True)
    for chunk in chunks:
        if isinstance(chunk, list):
            all_results.extend(chunk)

    logger.info(f"Crawl completo: {len(all_results)} registros.")
    return all_results
