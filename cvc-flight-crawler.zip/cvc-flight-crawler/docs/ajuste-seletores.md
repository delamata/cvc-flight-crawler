# Guia: Ajuste dos Seletores CSS

## Por que ajustar?

O site da CVC pode alterar os nomes das classes CSS a qualquer momento.
Os seletores em `crawler/parser.py` devem ser validados contra o HTML real.

## Como inspecionar

```bash
# 1. Ative modo visual (não headless)
# No .env: HEADLESS=false

# 2. Execute uma rota de teste
python -c "
import asyncio
from crawler.cvc_spider import scrape_route
from datetime import date
asyncio.run(scrape_route('GRU', 'MIA', date(2025,7,10), date(2025,7,17)))
"
```

## Onde atualizar

Arquivo: `crawler/parser.py`  
Função: `parse_flight_results()`

Substitua os seletores nas variáveis `cards`, `price_el` e `airline_el`
com os valores encontrados no DevTools do browser.

## Dica

Use `page.screenshot(path='debug.png')` no spider para capturar a tela durante o crawl.
